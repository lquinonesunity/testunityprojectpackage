using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace DLLTest
{
    public class Class2
    {
        public static void ShowAMessage()
        {
            Debug.Log("Class2: ShowAMessage()");
        }
    }
}