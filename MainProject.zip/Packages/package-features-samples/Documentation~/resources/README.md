This folder contains all images and media files used in the documentation markdown files, such as those in the [`Documentation~/manual`](/Documentation~/manual) folder.
