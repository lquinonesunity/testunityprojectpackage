This folder contains markdown files listed under "Manual" section in the documentation.  When adding or removing any files in this folder, don't forget to update `toc.yml` accordingly!
